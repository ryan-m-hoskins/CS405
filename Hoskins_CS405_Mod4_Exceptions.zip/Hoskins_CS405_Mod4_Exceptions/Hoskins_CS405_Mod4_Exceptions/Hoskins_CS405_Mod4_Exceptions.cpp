// Hoskins_CS405_Mod4_Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

// Custom Exception class accessing the std::exception
class CustomException : public std::exception {
public: 
    // Pointer to constant char string from what() is overridden to indicate no exceptions will be throw from this function and will just return custom message
    const char* what() const noexcept override {
        return "Here's an example of a custom C++ error";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    // 
    // Standard exception is thrown 
    throw std::exception("A standard exception has occurred.");
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    // Initiates try-catch block
    try {
        // If method, output message
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    // Catch the standard exception
    catch (const std::exception& e) {
        // Output error message using e.what()
        std::cerr << e.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception and catch it explictly in main

    // Throw CustomException
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using a standard C++ defined exception
    // If den is zero, throw runtime error indicate the program cannot divide by zero
    if (den == 0) {
        throw std::runtime_error("Cannot divide by zero\n");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown by divide.

    float numerator = 10.0f;
    float denominator = 0;
    // Initiates try catch block to divide
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    // Catch the runtime_error and display error message
    catch (const std::runtime_error& e) {
        std::cerr << "A runtime error occurred: " << e.what() << std::endl;
    }

}

int main()
{
    // Try catch blocks in main function to run functions
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        // TODO: Create exception handlers that catch (in this order):
        //  your custom exception
        //  std::exception
        //  uncaught exception 
        //  that wraps the whole main function, and displays a message to the console.
        do_division();
        do_custom_application_logic();
    }
    // Catch CustomException and indicate such an error occurred
    catch (const CustomException& e) {
        std::cerr << "Custom Exception occurred: " << e.what() << std::endl;
    }
    // Catch standard exception and output message for user
    catch (const std::exception& e) {
        std::cerr << "Standard Exception ocurred: " << e.what() << std::endl;
    }
    // Catch any uncaught exception and output message indicating one occurred to user
    catch (...) {
        std::cerr << "Uncaught exception occurred" << std::endl;
    }

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
